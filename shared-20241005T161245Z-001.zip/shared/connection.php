<?php

$conn=new mysqli("localhost","root","","acmeintern",3306);


?>