<?php

$conn=new mysqli("localhost","root","","acmeintern",3306);

mysqli_query($conn,"insert into user(username,password,usertype) values('$_POST[username]','$_POST[password]','$_POST[usertype]')");
$password_entered=$_POST['password'];
$password=password_hash($password_entered,PASSWORD_DEFAULT);

?>