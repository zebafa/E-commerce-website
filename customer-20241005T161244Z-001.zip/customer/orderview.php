<?php
// Check if the orders file exists
$filename = 'orders.txt';

if (file_exists($filename)) {
    // Read the contents of the file
    $orders = file_get_contents($filename);

    // Split the orders by line breaks for easier display
    $orderArray = explode("\n\n", trim($orders));

    // HTML structure for displaying orders
    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>View Orders</title>
        <link rel='stylesheet' href='styles.css'>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                padding: 20px;
            }
            .container {
                max-width: 800px;
                margin: auto;
                background: #fff;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
            h1 {
                text-align: center;
                color: #333;
            }
            pre {
                background: #f9f9f9;
                border: 1px solid #ccc;
                padding: 10px;
                border-radius: 4px;
                white-space: pre-wrap; /* Allows wrapping of text */
                word-wrap: break-word; /* Break long words */
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <h1>Order List</h1>";

    // Display each order
    if (!empty($orderArray)) {
        foreach ($orderArray as $order) {
            echo "<pre>$order</pre><hr>";
        }
    } else {
        echo "<p>No orders found.</p>";
    }

    echo "</div>
    </body>
    </html>";
} else {
    echo "Orders file not found.";
}
?>
