<?php
$cartid = $_GET['cartid'];
echo "recieved cartid=$cartid";
include "authguard.php";
include "../shared/connection.php";

mysqli_query($conn, "delete from cart where cartid=$cartid");
echo $cartid;

header("location:viewcart.php");
?>